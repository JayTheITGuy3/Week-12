from breezypythongui import EasyFrame
from tkinter import PhotoImage
from cards import Card
from cards import Deck


class CardDealing(EasyFrame):

    def __init__(self):
        EasyFrame.__init__(self, width=420, height=400, title="Random Card Dealing")
        self.card1 = "b"
        self.cardLabel1 = self.addLabel(text="", row=0, column=1, sticky="NSEW")

        self.cardInfo = self.addLabel(text="Card of Something", row=1, column=1, sticky="NSEW")

        self.addButton(row=2, column=0, text="Deal", command=self.deal)
        self.addButton(row=2, column=1, text="Shuffle", command=self.shuffle)
        self.addButton(row=2, column=2, text="New Deck", command=self.newDeck)

        self.refreshImages(self.card1)

    def deal(self):
        """   """

    def shuffle(self):
        """   """

    def newDeck(self):
        """   """

    def refreshImages(self, cardSpot):
        """Updates the images in the window."""
        fileName1 = str(self.card1) + ".gif"
        self.image1 = PhotoImage(file=fileName1)
        self.cardLabel1["image"] = self.image1


def main():
    CardDealing().mainloop()


if __name__ == "__main__":
    main()
