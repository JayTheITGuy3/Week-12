from breezypythongui import EasyFrame
from tkinter import PhotoImage
from cards import *
import random


class CardDealing(EasyFrame):

    def __init__(self):
        EasyFrame.__init__(self, width=420, height=400, title="Random Card Dealing")

        self.cardStringInfo = ""
        self.actualCard = ""

        self.rank = ""
        self.suit = "b"
        self.card1 = self.rank + self.suit
        self.cardDeck = Deck()
        self.cardLabel1 = self.addLabel(text="", row=0, column=1, sticky="NSEW")

        self.cardText = self.addLabel(text=str(self.actualCard), row=1, column=1, sticky="NSEW")

        self.addButton(row=2, column=0, text="Deal", command=self.newDeal)
        self.addButton(row=2, column=1, text="Shuffle", command=self.newShuffle)
        self.addButton(row=2, column=2, text="New Deck", command=self.newDeck)

        self.refreshImages()

    def convert(self):

        self.cardInfo()

        self.rankList = str(self.singleCard).split()

        if self.rankList[0] == "Ace":
            self.rank = 1
        elif self.rankList[0] == 'Jack':
            self.rank = 11
        elif self.rankList[0] == 'Queen':
            self.rank = 12
        elif self.rankList[0] == 'King':
            self.rank = 13
        else:
            self.rank = self.rankList[0]

        if self.rankList[2] == 'Clubs':
            self.suit = "c"
        elif self.rankList[2] == 'Diamonds':
            self.suit = "d"
        elif self.rankList[2] == 'Hearts':
            self.suit = "h"
        else:
            self.suit = "s"

        self.actualCard = str(self.rank) + " of " + str(self.suit)

        self.refreshImages()

        return self.actualCard

    def newDeal(self):
        """  Resets the dealing """
        self.singleCard = self.cardDeck.deal()
        self.convert()

    def newShuffle(self):
        """  Shuffles the Card """
        self.cardDeck.shuffle()
        self.rank = ""
        self.suit = "b"
        self.card1 = self.rank + self.suit

    def newDeck(self):
        """ Resets the deck object """
        self.cardDeck = Deck()
        self.rank = ""
        self.suit = "b"
        self.card1 = self.rank + self.suit

        self.addLabel(text="", row=1, column=1, sticky="NSEW")
        self.refreshImages()

    def refreshImages(self):
        """Updates the images in the window."""
        fileName1 = "DECK/" + str(self.rank) + str(self.suit) + ".gif"
        self.image1 = PhotoImage(file=fileName1)
        self.cardLabel1["image"] = self.image1

    def cardInfo(self):
        self.addLabel(text=str(self.singleCard), row=1, column=1, sticky="NSEW")


def main():
    CardDealing().mainloop()


if __name__ == "__main__":
    main()
