

class CustomDeck:
    """This class represents a 52 card deck."""

    def __init__(self):
        """Starts the program off with the back of the card"""
        var = "b"
        self.text = var
